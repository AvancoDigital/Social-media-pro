import React, { useState } from 'react';
import Button from './Button';
import { KIWIFY_LINK } from '../../data';

interface ContactFormProps {
  buttonText?: string;
  withHeading?: boolean;
  headingText?: string;
}

const ContactForm: React.FC<ContactFormProps> = ({
  buttonText = 'QUERO GANHAR R$5.000/MÊS →',
  withHeading = false,
  headingText = 'INSCREVA-SE HOJE E GANHE 3 BÔNUS EXCLUSIVOS!'
}) => {
  const [form, setForm] = useState({
    name: '',
    email: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Redirect to Kiwify payment link
    window.open(KIWIFY_LINK, '_blank');
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-lg p-4 sm:p-6 border border-gray-200">
      {withHeading && (
        <h3 className="text-center text-lg sm:text-xl font-bold mb-3 sm:mb-4 text-secondary px-2">
          {headingText}
        </h3>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
        <div>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Nome"
            required
            className="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-sm sm:text-base"
          />
        </div>
        
        <div>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="E-mail"
            required
            className="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-sm sm:text-base"
          />
        </div>
        
        <Button 
          variant="primary" 
          size="lg" 
          fullWidth 
          withArrow
          href={KIWIFY_LINK}
        >
          <span className="text-sm sm:text-base">{buttonText}</span>
        </Button>
      </form>
      
      <p className="text-xs text-center mt-3 sm:mt-4 text-gray-500">
        Seus dados estão seguros e nunca serão compartilhados.
      </p>
    </div>
  );
};

export default ContactForm;