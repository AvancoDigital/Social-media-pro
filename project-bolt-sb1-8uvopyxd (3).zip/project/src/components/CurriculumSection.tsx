import React from 'react';
import { User, Target, MessageSquare, BarChart2, PenTool, TrendingUp, LineChart, Award } from 'lucide-react';

const CurriculumSection: React.FC = () => {
  const skills = [
    { icon: Target, text: 'Definição de público-alvo' },
    { icon: MessageSquare, text: 'Identidade digital de marcas' },
    { icon: BarChart2, text: 'Planos de comunicação' },
    { icon: PenTool, text: 'Técnicas de copywriting' },
    { icon: TrendingUp, text: 'Impulsionamento de Perfis' },
    { icon: LineChart, text: 'Inbound Marketing' },
    { icon: BarChart2, text: 'Estratégias de Marketing de influência' },
    { icon: LineChart, text: 'Cálculo ROI e análise de métricas' }
  ];

  return (
    <section className="py-12 sm:py-16 bg-gradient-to-br from-pink-400 to-blue-400 text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Seu currículo no futuro
            </h2>
          </div>
          
          <div className="bg-white rounded-lg p-4 sm:p-6 lg:p-8 shadow-xl w-full max-w-lg mx-auto lg:max-w-none">
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                <img 
                  src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=300" 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-center sm:text-left flex-grow">
                <h3 className="text-gray-900 font-bold text-base sm:text-lg">Seu nome</h3>
                <p className="text-gray-600 text-sm sm:text-base">Especialista em Social Media Marketing</p>
              </div>
              <div className="text-center sm:text-right">
                <div className="text-gray-900 font-bold text-lg sm:text-xl">R$ 7.119/mês*</div>
                <div className="text-xs sm:text-sm text-gray-500">Ref: Glassdoor para São Paulo</div>
              </div>
            </div>
            
            <div className="mb-6 sm:mb-8">
              <h4 className="text-gray-900 font-bold mb-3 sm:mb-4 text-base sm:text-lg">Habilidades</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                {skills.map((skill, index) => (
                  <div key={index} className="flex items-center gap-2 text-gray-700">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-red-100 flex items-center justify-center text-red-500 flex-shrink-0">
                      <skill.icon size={12} className="sm:w-4 sm:h-4" />
                    </div>
                    <span className="text-xs sm:text-sm">{skill.text}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-gray-900 font-bold mb-3 sm:mb-4 text-base sm:text-lg">Certificado pela AVANÇO</h4>
              <div className="bg-gray-100 rounded-lg p-3 sm:p-4 flex items-center gap-3 sm:gap-4">
                <Award className="text-primary h-8 w-8 sm:h-12 sm:w-12 flex-shrink-0" />
                <div>
                  <div className="text-gray-900 font-bold text-sm sm:text-base">Certificado Profissional</div>
                  <div className="text-gray-600 text-xs sm:text-sm">Social Media Manager</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CurriculumSection;