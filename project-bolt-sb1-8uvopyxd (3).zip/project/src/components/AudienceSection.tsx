import React from 'react';
import { audience } from '../data';
import * as LucideIcons from 'lucide-react';

const AudienceSection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-4">
          PARA QUEM É ESTE <span className="text-primary">E-BOOK</span>?
        </h2>
        
        <p className="text-base sm:text-lg text-center text-gray-600 mb-8 sm:mb-12 max-w-3xl mx-auto px-2">
          O Social Media Pro foi desenvolvido para ajudar pessoas de diferentes perfis a dominarem as redes sociais e monetizarem seu conhecimento.
        </p>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {audience.map((item) => {
            // @ts-ignore - Dynamic import from lucide-react
            const Icon = LucideIcons[item.icon];
            
            return (
              <div 
                key={item.id} 
                className="bg-gray-100 p-6 sm:p-8 rounded-lg text-center transform transition-all duration-300 hover:-translate-y-2 hover:shadow-lg"
              >
                <div className="bg-primary text-white p-3 sm:p-4 rounded-full w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center mx-auto mb-4 sm:mb-6">
                  {Icon && <Icon className="h-6 w-6 sm:h-8 sm:w-8" />}
                </div>
                
                <h3 className="text-lg sm:text-xl font-bold mb-3 sm:mb-4">{item.title}</h3>
                
                <p className="text-gray-600 text-sm sm:text-base">{item.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default AudienceSection;