import React from 'react';
import ContactForm from './shared/ContactForm';
import CountdownTimer from './shared/CountdownTimer';

const CTASection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 bg-gradient-to-br from-secondary to-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-4">
            COMECE A FATURAR COM <span className="text-primary">REDES SOCIAIS</span> HOJE MESMO!
          </h2>
          
          <p className="text-base sm:text-lg text-center mb-6 sm:mb-8 text-gray-300 px-2">
            Não perca mais tempo! Adquira agora o Social Media Pro e comece a transformar sua carreira.
          </p>
          
          <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 items-center">
            <div>
              <div className="bg-white/10 backdrop-blur-sm p-4 sm:p-6 rounded-lg border border-white/20 mb-4 sm:mb-6">
                <h3 className="text-lg sm:text-xl font-bold mb-3 sm:mb-4">O que você vai receber:</h3>
                
                <ul className="space-y-3 sm:space-y-4">
                  <li className="flex items-start">
                    <span className="text-primary font-bold mr-2 flex-shrink-0">1.</span>
                    <div>
                      <span className="font-semibold text-sm sm:text-base">E-book Social Media Pro</span>
                      <p className="text-gray-300 text-xs sm:text-sm">Guia completo com todas as estratégias e técnicas.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary font-bold mr-2 flex-shrink-0">2.</span>
                    <div>
                      <span className="font-semibold text-sm sm:text-base">Checklist "Primeiro Cliente em 48h"</span>
                      <p className="text-gray-300 text-xs sm:text-sm">Passo a passo para conquistar seu primeiro cliente rapidamente.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary font-bold mr-2 flex-shrink-0">3.</span>
                    <div>
                      <span className="font-semibold text-sm sm:text-base">Templates de Posts Prontos</span>
                      <p className="text-gray-300 text-xs sm:text-sm">PDF editável com modelos para diferentes objetivos e plataformas.</p>
                    </div>
                  </li>
                </ul>
                
                <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div>
                    <span className="text-gray-400 line-through text-sm sm:text-base">De R$97,90</span>
                    <div className="text-lg sm:text-xl md:text-2xl font-bold">Por apenas 8x de R$4,74</div>
                    <div className="text-xs sm:text-sm text-gray-300">ou R$37,92 à vista</div>
                  </div>
                  <div className="bg-primary text-white text-xs font-bold py-1 px-2 sm:px-3 rounded-full self-start sm:self-center">
                    61% OFF
                  </div>
                </div>
              </div>
              
              <CountdownTimer />
            </div>
            
            <div className="w-full max-w-md mx-auto lg:max-w-none">
              <ContactForm 
                buttonText="QUERO GANHAR R$5.000/MÊS →" 
                withHeading 
                headingText="INSCREVA-SE HOJE E GANHE 3 BÔNUS EXCLUSIVOS!" 
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;