import React from 'react';
import { benefits, stats } from '../data';
import * as LucideIcons from 'lucide-react';

const WhySection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
          POR QUE <span className="text-primary">SOCIAL MEDIA PRO</span>?
        </h2>
        
        <div className="max-w-4xl mx-auto mb-12 sm:mb-16">
          <p className="text-base sm:text-lg text-center mb-6 sm:mb-8 px-2">
            Estudos da Forbes comprovam: o mercado de Social Media cresceu 312% em 2024, mas faltam profissionais qualificados. Com o Social Media Pro, você dominará:
          </p>
          
          <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
            {benefits.map((benefit) => {
              // @ts-ignore - Dynamic import from lucide-react
              const Icon = LucideIcons[benefit.icon];
              
              return (
                <div 
                  key={benefit.id} 
                  className="bg-white p-4 sm:p-6 rounded-lg shadow-card hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-2 sm:p-3 rounded-full mr-3 sm:mr-4 flex-shrink-0">
                      {Icon && <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />}
                    </div>
                    <div>
                      <h3 className="font-bold text-base sm:text-lg mb-2">{benefit.title}</h3>
                      <p className="text-gray-600 text-sm sm:text-base">{benefit.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {stats.map((stat) => (
            <div 
              key={stat.id} 
              className="bg-secondary text-white p-4 sm:p-6 rounded-lg text-center hover:scale-105 transition-transform duration-300"
            >
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-primary mb-2">{stat.value}</div>
              <p className="text-gray-300 text-sm sm:text-base">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhySection;