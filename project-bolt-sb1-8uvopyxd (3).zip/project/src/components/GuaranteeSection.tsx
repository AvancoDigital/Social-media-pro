import React from 'react';
import { ShieldCheck } from 'lucide-react';
import Button from './shared/Button';
import { KIWIFY_LINK } from '../data';

const GuaranteeSection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 bg-gray-100" id="garantia">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-1/3 bg-primary p-6 sm:p-8 flex items-center justify-center">
              <ShieldCheck className="h-24 w-24 sm:h-32 sm:w-32 text-white" />
            </div>
            
            <div className="lg:w-2/3 p-6 sm:p-8">
              <h2 className="text-2xl sm:text-3xl font-bold mb-4">
                Garantia de <span className="text-primary">7 Dias</span>
              </h2>
              
              <p className="text-base sm:text-lg mb-4 sm:mb-6">
                Estamos tão confiantes que o Social Media Pro vai transformar sua carreira que oferecemos uma garantia incondicional de 7 dias.
              </p>
              
              <div className="bg-gray-100 p-4 rounded-lg mb-4 sm:mb-6">
                <p className="font-bold mb-2 text-sm sm:text-base">Como funciona:</p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="text-primary mr-2 flex-shrink-0">✓</span>
                    <span className="text-sm sm:text-base">Adquira o e-book agora mesmo</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 flex-shrink-0">✓</span>
                    <span className="text-sm sm:text-base">Estude o conteúdo por até 7 dias</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 flex-shrink-0">✓</span>
                    <span className="text-sm sm:text-base">Se não estiver satisfeito, solicite reembolso total</span>
                  </li>
                </ul>
              </div>
              
              <p className="italic text-gray-600 mb-4 sm:mb-6 text-sm sm:text-base">
                "Se você não amar o conteúdo, devolvemos 100% do seu dinheiro. Sem perguntas, sem burocracia!"
              </p>
              
              <Button href={KIWIFY_LINK} variant="primary" size="lg" withArrow>
                QUERO GANHAR R$5.000/MÊS →
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GuaranteeSection;